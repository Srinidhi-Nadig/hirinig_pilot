import boto3
from botocore.exceptions import NoCredentialsError

def send_email(email_sender, email_recipient, email_subject, email_message):
    # Replace 'your-region' with your AWS region
    aws_region = 'us-west-2'

    # Set up the SES client
    ses = boto3.client('ses', region_name=aws_region)

    # Create the message
    message = {
        'Subject': {'Data': email_subject},
        'Body': {'Text': {'Data': email_message}},
    }

    try:
        # Send the email
        response = ses.send_email(
            Source=email_sender,
            Destination={'ToAddresses': [email_recipient]},
            Message=message
        )

        print(f"Email sent! Message ID: {response['MessageId']}")

    except NoCredentialsError:
        print("Credentials not available")
    except Exception as e:
        print(f"Error: {e}")


def sendRejectionEmailFunction(email_to,Email_Subject, Email_Body):
    send_email('hiringpilot@aws-automation123.awsapps.com', email_to, Email_Subject, Email_Body)
    

def sendEmailFunction(email_to,candidate_Name,selection_status):
    # print("Send A Notification Email")
    email_subject = 'Application Process Status for the '+ candidate_Name +' is : '+ selection_status
    email_body = 'Dear '+candidate_Name +'\n\n\nThank you for the interest shown for the dentsu. Your process review status is : ' + selection_status + '. \n\n link: https://dd08f4ec4ced48a7b9cca762a57cf1d7.vfs.cloud9.us-west-2.amazonaws.com/ \n\n\nThanks and Regards,\n Hiring Pilot'
    send_email('hiringpilot@aws-automation123.awsapps.com', email_to, email_subject, email_body)
    

def sendFinalEmail(jsondata):
    # Extract relevant values from jsondata
    # print("Send A Final Notification Email")
    candidate_Name = jsondata["User_Name"]
    job_Title = jsondata["job_Title"]
    email_subject = f'L1 Interview for {job_Title} completed by {candidate_Name}'
    
    email_body = f'Hi Shanta,\n\n\n'
    email_body += f'I am writing to inform you that the first round of interviews for the {job_Title} position has been completed.\n\n'
    email_body += f'Please find below the details of the interview:\n'
    email_body += f'• Name:{candidate_Name} \n • Email ID:{jsondata["User_Email"]} \n • Skills:{jsondata["Candidate_Skills"]} \n • Experience:{jsondata["User_Experience"]} \n • Current CTC:{jsondata["User_CurrentCTC"]} \n • Expected CTC:{jsondata["User_ExpectedCTC"]} \n • Test Score:{jsondata["Percentage_Score"]} \n • Profile Match Score:{jsondata["CandidateProfile_Score"]}\n\n'
    email_body += f'Thank you for the interest shown for the {job_Title}. Your process review status is: Successful\n\n\n'
    email_body += 'Thanks and Regards,\n Hiring Pilot'
    
    # print("Emiail Subject - " + "\n\n")
    # print(email_subject)
    # print("Emiail Body - " + "\n\n")
    # print(email_body)    
    
    #send_email('hiringpilot@aws-automation123.awsapps.com', "oinam.shantasingh@dentsu.com", email_subject, email_body)