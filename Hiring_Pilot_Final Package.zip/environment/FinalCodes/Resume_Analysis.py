import json
import AWSGen_AI
import MultiFunctions as mf


def Analyse_resume(resumeContent):
    # Extracting contents from the documents
    resume_info = resumeContent
    
    
    # candidate_email = AWS_Gen_AI.AWS_Gen_AI("Give only the email address. If not return as EmailBlank. Find email address from the below summary. e.g., abc@domain.com." + "\n " + resume_info)
    candidate_email = AWSGen_AI.AWS_Gen_AI("Give only the email address. Find email address and if not return as EmailBlank response. e.g., abc@domain.com." + "\n " + resume_info)
    if "EmailBlank" in candidate_email:
        candidate_email = mf.extract_emails(resume_info)
    
    
    # Using AWS GenAi retrieve candidate information
    candidate_Skills = mf.candidate_basic_details(resume_info)
    
    # Format the retrived resume data in the required format
    my_variable = mf.getSubstringBetweenTwoChars(candidate_Skills,'{','}')
    my_variable=my_variable+"}"
    data_dict = json.loads(my_variable)
    candidate_name = data_dict.get('name', None)
    candidate_skills  = ','.join(data_dict.get('skills', []))
    
    # Retrieve job details from job profile
    job_title = mf.job_title()
    required_skills = mf.job_skills()
    requierd_experience = mf.job_experience()
        
    # GenAI prompt
    prompt = f""" Just provide a short response as Successful or Unsuccessful by correlating candidate skills with the job required skills
    Candidate skills: {candidate_skills}
    And the job required skills: {", ".join(required_skills)}
    """
    
    # Analyze the profile with job profile
    finalSummary =  AWSGen_AI.AWS_Gen_AI(prompt)
    substring = "Successful"
    if substring in finalSummary:
        profileScore =  "Successful"
        # print(candidate_name + " - shortlisted for next level")
    else:
        profileScore =  "Unsuccessful"
        # print(candidate_name + " - not shortlisted for next level")
    

    return candidate_name, candidate_email, candidate_skills, profileScore