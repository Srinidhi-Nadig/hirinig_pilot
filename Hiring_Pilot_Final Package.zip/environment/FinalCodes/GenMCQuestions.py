import get_S3_KBs
import MultiFunctions as mf
import Candidate_KnowledgeTest


# Remove string before Q1
def remove_before_substring(input_string, substring):
    index = (input_string.find(substring) - 3)
    if index != -1:
        return input_string[index + len(substring):]
    return input_string


# Generate MCQ questions
def GenQuestions(Canidate_Name, Canidate_Email, no_Question):
    bucketName = "bedrock-hiringagent"
    job_title = mf.job_title()
    required_skills = mf.job_skills()
    requierd_experience = mf.job_experience()
    noQuestion = no_Question

    QuestionSource = get_S3_KBs.read_all_files_from_s3(bucketName)
    mcQuestions =  mf.create_MCQ(noOfQuestions=noQuestion, jobProfile=job_title, jobProfileSkills=required_skills, profilePreferredExp=requierd_experience, QuesSource=QuestionSource)
    return [mcQuestions, job_title, required_skills]