import boto3
import io
import docx
import os
import Resume_Analysis
import GenMCQuestions
import Candidate_KnowledgeTest
import MultiFunctions as mf
import EmailResponse
import Update_S3_profiles

def read_docx(file_obj):
    doc = docx.Document(io.BytesIO(file_obj))
    content = ""
    for para in doc.paragraphs:
        content += para.text
    return content

def read_all_files_from_s3(bucket_name):
    s3 = boto3.client('s3')
    try:
        response = s3.list_objects_v2(Bucket=bucket_name)
        if 'Contents' in response:
            for obj in response['Contents']:
                object_key = obj['Key']
                if object_key.endswith('.docx'):
                    obj_response = s3.get_object(Bucket=bucket_name, Key=object_key)
                    file_obj = obj_response['Body'].read()
                    content = read_docx(file_obj)
                    out_variable = object_key + "\n" + content
                    
                    candidate_name, candidate_email, candidate_skills, result = Resume_Analysis.Analyse_resume(out_variable)
                    if result == "Successful":
                        print(f"{candidate_name} is shortlisted")
                        
                        no_Question = 3
                        print("Generating MC Questions")
                        listmcq_Questions, job_title, job_Skills = GenMCQuestions.GenQuestions(candidate_name, candidate_email, no_Question)
                        
                        EmailResponse.sendEmailFunction(candidate_email,candidate_name,result) #Pass Paramenters
                        
                        for i in range(1, 5):
                            try:
                                print(f"Attempt {i}: Candidat knowledge test generation...")
                                
                                Candidate_KnowledgeTest.start_Test(listmcq_Questions, job_title, job_Skills, candidate_name, candidate_email, candidate_skills, result)
                                s3.delete_object(Bucket=bucket_name, Key=object_key)
                                
                                break
                            except Exception as e:
                                if i < 5:
                                    print(f"Attempt {i} failed: {e}. Retrying...")
                                    continue
                                else:
                                    print(f"Attempt {i} failed: {e}. Maximum attempts reached.")
                                    break
                    else:
                        print(f"{candidate_name}is not shortlisted" + "\n")
                        Email_Subject = f"Job application update for {job_title}"
                        Email_Body = f"Hi {candidate_name}, \n Thanks for your interest on {job_title}. Sorry to inform that Your profile has not been shortlisted. \n\n Regards,\nCode Warriors\nHiring Pilot"
                        EmailResponse.sendRejectionEmailFunction(candidate_email,Email_Subject=Email_Subject, Email_Body=Email_Body) # Pass Parameters
                        Update_S3_profiles.upload_file_to_s3(candidate_name + ".txt", Email_Body)
                        print(f"{candidate_name} record saved in database" + "\n")
                        
                else:
                    print(f"Ignoring object '{object_key}' as it's not a .docx file")
        else:
            print("No objects found in the bucket.")
    except Exception as e:
        print(f"Error reading from S3: {e}")


print("Extracting and Analyzing Candidate Profile against job profile" + "\n")
read_all_files_from_s3("extracted-emails")
