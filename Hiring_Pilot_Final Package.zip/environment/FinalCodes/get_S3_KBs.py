import boto3
import io
import docx
import PyPDF2
import AWSGen_AI

def read_docx(file_obj):
    doc = docx.Document(io.BytesIO(file_obj))
    content = ""
    for para in doc.paragraphs:
        content += para.text
    return content

def read_pdf(file_obj):
    pdf_reader = PyPDF2.PdfFileReader(io.BytesIO(file_obj))
    content = ""
    for page_num in range(pdf_reader.numPages):
        page = pdf_reader.getPage(page_num)
        content += page.extractText()
    return content

def read_all_files_from_s3(bucket_name):
    # Initialize the S3 client
    s3 = boto3.client('s3')
    out_variable=""
    try:
        # List all objects in the bucket
        response = s3.list_objects_v2(Bucket=bucket_name)
        
        # Check if objects were found
        if 'Contents' in response:
            for obj in response['Contents']:
                # Get the object key
                object_key = obj['Key']
                
                # Check if the file has .docx or .pdf extension
                if object_key.endswith('.docx') or object_key.endswith('.pdf'):
                    # Get the object from S3
                    obj_response = s3.get_object(Bucket=bucket_name, Key=object_key)
                    
                    # Read the data from the response
                    file_obj = obj_response['Body'].read()
                    
                    # Process the file based on its type
                    if object_key.endswith('.docx'):
                        content = read_docx(file_obj)
                    elif object_key.endswith('.pdf'):
                        content = read_pdf(file_obj)
                    out_variable = out_variable +"\n"+ object_key+"\n"+ content

                    
                else:
                    print(f"Ignoring object '{object_key}' as it's not a .docx or .pdf file")
        
        else:
            print("No objects found in the bucket.")
    
    except Exception as e:
        print(f"Error reading from S3: {e}")
    return out_variable
    #print(out_variable)
    # gptPromt = "Give me " +  str(10) + " MCQ for " +"RPA Developer Uipath"+"with"+"Skills:reframework, document understanding"+" along with options and right answer. no additional texts"
    # questions =  AWS_Gen_AI.AWS_Gen_AI(gptPromt + "from below topics"+ out_variable)
    # print(questions)
# Example usage
# bucket_name = 'bedrock-hiringagent'
# read_all_files_from_s3(bucket_name)
