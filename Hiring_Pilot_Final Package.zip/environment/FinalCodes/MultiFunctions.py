import AWSGen_AI
import os
import re
import docx2txt
import requests

file_path = os.getcwd() + "/Sample_Job_profile.txt"  # Replace this with the path to your text file
def job_skills():
#job_profile = os.rea d()  
    try:
        with open(file_path, 'r') as file:
            # Read the entire contents of the file
            file_contents = file.read()
            input_prompt = "Find the required skills from the below job profile as json array" + "\n " + file_contents
            reqd_skills = AWSGen_AI.AWS_Gen_AI(input_prompt)
            # print(reqd_skills)
            return reqd_skills
    except FileNotFoundError:
        print("File not found. Please check the file path.")
    except Exception as e:
        print("An error occurred:", e)


def job_experience():
#job_profile = os.rea d()  
    try:
        with open(file_path, 'r') as file:
            # Read the entire contents of the file
            file_contents = file.read()
            input_prompt = " what is the overall requested/minimum experience in below job profile, give only the number.  say exp not mentioned if not found " + "\n " + file_contents
            reqd_exp = AWSGen_AI.AWS_Gen_AI(input_prompt)
            # print(reqd_exp)
            return reqd_exp
    except FileNotFoundError:
        print("File not found. Please check the file path.")
    except Exception as e:
        print("An error occurred:", e)
        
        
def job_title():
#job_profile = os.rea d()  
    try:
        with open(file_path, 'r') as file:
            # Read the entire contents of the file
            file_contents = file.read()
            input_prompt = " what is the mentioned job title in below job profile, give only the number. " + "\n " + file_contents
            reqd_title = AWSGen_AI.AWS_Gen_AI(input_prompt)
            # print(reqd_title)
            return reqd_title
    except FileNotFoundError:
        print("File not found. Please check the file path.")
    except Exception as e:
        print("An error occurred:", e)
        
        
def candidate_basic_details(file_contents):
    #file_path = os.getcwd() + "/Inputs/resumeContent.txt"
    #print(file_path)
#job_profile = os.rea d()  
    try:
        input_prompt = " From the below profile extract: name, education, skills only in json format exclude additional texts." + "\n " + file_contents
        reqd_title = AWSGen_AI.AWS_Gen_AI(input_prompt)
        #print(type(reqd_title))
        #print(reqd_title)
        return reqd_title
    except FileNotFoundError:
        print("File not found. Please check the file path.")
    except Exception as e:
        print("An error occurred:", e)
        
def getSubstringBetweenTwoChars(userDetails,ch1,ch2):
    return userDetails[userDetails.find(ch1,1):userDetails.rfind(ch2,1)]        


#Get emails from resume content
def extract_emails(text):
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    emails = re.findall(email_pattern, text)
    return ''.join(emails)
    

#To read the resumes
def extract_information_from_resume(docx_path):
    resumeContent = docx2txt.process(docx_path)
    resume_info = resumeContent
    return resume_info

# create MCQ questions
def create_MCQ(noOfQuestions, jobProfile, jobProfileSkills, profilePreferredExp, QuesSource):
    gptPromt = f"Give me {noOfQuestions} techincal MCQ related to Skills: {jobProfileSkills}. Options with one right answer (e.g., Q1, a), b), c), d), Ans: a)). Tag all the questions with Q sequence and correct answer as Ans and no additional texts"
    # gptPromt = f"I'm looking for multiple-choice questions with answers on the topics: {jobProfileSkills}. Could you provide me with {noOfQuestions} questions along with their respective answer choices and correct answers? Here are some guidelines for the questions: Difficulty level: medium, Desired format:  question,  answer choice,  correct answer"
    questions =  AWSGen_AI.AWS_Gen_AI(gptPromt + "from below topics "+ QuesSource)
    return questions
    
    
# Send an final notification email
def send_FinalNotification(json_Data):
    api_Url = "https://prod-35.westeurope.logic.azure.com:443/workflows/05cf9041bb6243c29265622bd7e41d2a/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=UE9goBkeoM9ebGea5WKiZqU3thkA8gBqsiQEDdxAokw"
    response = requests.post(api_Url, json=json_Data)
    return response