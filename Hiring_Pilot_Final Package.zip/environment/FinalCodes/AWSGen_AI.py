import anthropic_bedrock
from anthropic_bedrock import AnthropicBedrock
def AWS_Gen_AI(input_content):
    client = AnthropicBedrock(
        # Authenticate by either providing the keys below or use the default AWS credential providers, such as
        # using ~/.aws/credentials or the "AWS_SECRET_ACCESS_KEY" and "AWS_ACCESS_KEY_ID" environment variables.
        # aws_access_key="ASIA4FBYU7KC4FU2K4VU",
        # aws_secret_key="MXwU9lUhHaSIWz4nLWm77Zntridt3FNnGh+w4S5D",
        # # Temporary credentials can be used with aws_session_token.
        # # Read more at https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp.html.
        # aws_session_token="IQoJb3JpZ2luX2VjEEkaCXVzLWVhc3QtMSJHMEUCIQDMXMZBojWdwwhAyOss55h6C6VbZGQkwUx0bC03uIyJ8AIgD7D4OzMaNfR86RRtfLatSi9YJYDZDEyOgV7BrF2ua5AqmQIIEhACGgw4MzU0ODk5NTQ0MzciDFmRjZawNO+D9G3XzCr2AdLGx/kuP1Gaq4jIfJK9UErCZ0KBOxJVA5w1tkbVazWqsouULsIaxqWyXdXOOc6s3+zgxALCRGl8aog2NIlGFgsJQfXg6p63C1kxZmGk+aahnHsKO8VuuH+DLS5SM24YMIVnlODoARyYk9NFBmeSO1kviF4txd6/AC0/tAPE1mqJLq0v6YkWKSi7EpnekNgYQVVNJQpx6KxMm5LnCNuMyviXKKGJSUJ2UF1myYFjURe/t9xImHxXHdXVGE8OYBK8/bqHY7gQWcZgTp56gjKw9/fvGOpZTgWgTUuimrpBd+zASTdJRYpGWsiKU7IhBTzX36xaxbtblTCx9OKtBjqdAcp7/LgJQZp042VSdCW/TqAySuADHKAc3U0NrNismvrdQvOb2RGF/G+1ISUoEm7Mn67V8eYY7/4hVwVJfiWPGW+8+c105S5TNUaJHlI+dvIVBPHjXbvSfkEUKDvZUteUBBFDeBR/WlfRdrlDYqnoOrKiwkaJANTPemM1dzCdXBveqqf/06BuQHtXkm7fPE0/BLrr+/R5dwPWJ0TJisM=",
        # # aws_region changes the aws region to which the request is made. By default, we read AWS_REGION,
        # # and if that's not present, we default to us-east-1. Note that we do not read ~/.aws/config for the region.
        aws_region="us-west-2",
    )
    
    completion = client.completions.create(
        model="anthropic.claude-v2:1",
        max_tokens_to_sample=256,
        prompt=f"{anthropic_bedrock.HUMAN_PROMPT} {input_content} {anthropic_bedrock.AI_PROMPT}",
    )
    return(completion.completion)
    

# import boto3

# bedrock = boto3.client(service_name="bedrock")
# response = bedrock.list_foundation_models(byProvider="anthropic")

# for summary in response["modelSummaries"]:
#     print(summary["modelId"])
    
    
    
# anthropic.claude-instant-v1:2:100k
# anthropic.claude-instant-v1
# anthropic.claude-v1
# anthropic.claude-v2:0:18k
# anthropic.claude-v2:0:100k
# anthropic.claude-v2:1:18k
# anthropic.claude-v2:1:200k
# anthropic.claude-v2:1
# anthropic.claude-v2


