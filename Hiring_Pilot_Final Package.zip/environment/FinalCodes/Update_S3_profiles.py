import boto3

def upload_file_to_s3(file_name, file_content):
    """
    Uploads a file to an S3 bucket.

    :param bucket_name: Name of the S3 bucket.
    :param file_name: Name of the file to be uploaded.
    :param file_content: Content of the file to be uploaded.
    """
    bucket_name = 'getresponses-bucket'
    s3 = boto3.client('s3')
    try:
        s3.put_object(Bucket=bucket_name, Key=file_name, Body=file_content)
        print(f"File '{file_name}' uploaded successfully to bucket '{bucket_name}'.")
    except Exception as e:
        print(f"Error uploading file '{file_name}' to bucket '{bucket_name}': {e}")

# Example usage

# file_name = 'example file.txt'
# file_content = b'Hello, world!'
# upload_file_to_s3(file_name, file_content)
