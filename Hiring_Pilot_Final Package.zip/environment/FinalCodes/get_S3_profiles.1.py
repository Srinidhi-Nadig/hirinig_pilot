import boto3
import io
import docx
# import PyPDF2
import os
import Resume_Analysis
import GenMCQuestions
import Candidate_KnowledgeTest
import MultiFunctions as mf


def read_docx(file_obj):
    doc = docx.Document(io.BytesIO(file_obj))
    content = ""
    for para in doc.paragraphs:
        content += para.text
    return content

# def read_pdf(file_obj):
#     pdf_reader = PyPDF2.PdfFileReader(io.BytesIO(file_obj))
#     content = ""
#     for page_num in range(pdf_reader.numPages):
#         page = pdf_reader.getPage(page_num)
#         content += page.extractText()
#     return content

def read_all_files_from_s3(bucket_name):
    # Initialize the S3 client
    s3 = boto3.client('s3')
    out_variable=""
    try:
        # List all objects in the bucket
        response = s3.list_objects_v2(Bucket=bucket_name)
        
        # Check if objects were found
        if 'Contents' in response:
            for obj in response['Contents']:
                # Get the object key
                object_key = obj['Key']
                
                # Check if the file has .docx or .pdf extension
                if object_key.endswith('.docx') or object_key.endswith('.pdf'):
                    # Get the object from S3
                    obj_response = s3.get_object(Bucket=bucket_name, Key=object_key)
                    
                    # Read the data from the response
                    file_obj = obj_response['Body'].read()
                    
                    # Process the file based on its type
                    if object_key.endswith('.docx'):
                        content = read_docx(file_obj)
                    # elif object_key.endswith('.pdf'):
                    #     # content = read_pdf(file_obj)
                    #     print("No PDF Supported")
                    
                    out_variable = object_key+"\n"+ content
                    # print(out_variable)# Print or process the content
                    
                    candidate_name, candidate_email, candidate_skills, result = Resume_Analysis.Analyse_resume(out_variable)
                    
                    if result == "Successful":
                        no_Question = 3
                        listmcq_Questions, job_title, job_Skills = GenMCQuestions.GenQuestions(candidate_name, candidate_email, no_Question)
                        
                        Email_Subject = f"Profile shortlisted for {job_title}",
                        Email_Body = f"Hi {candidate_name}, \n You profile has been shortlisted for {job_title}. \n Please complete your assessment by clicking on the below given link. \n link: https://dd08f4ec4ced48a7b9cca762a57cf1d7.vfs.cloud9.us-west-2.amazonaws.com/ \n\n Regards,\nCode Warriors\nHiring Pilot"
                        jsondata = {
                        "EmailTo":candidate_email,
                        "EmailSubject": Email_Subject,
                        "EmailBody":Email_Body
                        }
                        
                        EmailSendStatus = mf.send_Notification(json_Data=jsondata)
                        print(EmailSendStatus)
                        
                        
                        
                        for i in range(1,5):
                            try:
                                print(f"Attempt {i}: Execution started successfully...")
                                Candidate_KnowledgeTest.start_Test(listmcq_Questions, job_title, job_Skills, candidate_name, candidate_email, candidate_skills, result)
                                s3.delete_object(Bucket=bucket_name, Key=object_key)
                                break
                            except Exception as e:
                                if i < 5:
                                    print(f"Attempt {i} failed: {e}. Retrying...")
                                    continue
                                else:
                                    print(f"Attempt {i} failed: {e}. Maximum attempts reached.")
                                    break                        
                    else:
                        # print(result + "\n")
                        Email_Subject = f"Job application update for {job_title}",
                        Email_Body = f"Hi {candidate_name}, \n Thanks for your interest on {job_title}. Sorry to inform that Your profile has not been shortlisted. \n\n Regards,\nCode Warriors\nHiring Pilot"
                        jsondata = {
                        "EmailTo":candidate_email,
                        "EmailSubject":Email_Subject,
                        "EmailBody":Email_Body
                        }
                        
                        EmailSendStatus = mf.send_Notification(json_Data=jsondata)
                        print(EmailSendStatus)
                    
                else:
                    print(f"Ignoring object '{object_key}' as it's not a .docx or .pdf file")
    
        else:
            print("No objects found in the bucket.")
    
    except Exception as e:
        print(f"Error reading from S3: {e}")
    #return out_variable
    #print(out_variable)
    # gptPromt = "Give me " +  str(10) + " MCQ for " +"RPA Developer Uipath"+"with"+"Skills:reframework, document understanding"+" along with options and right answer. no additional texts"
    # questions =  AWS_Gen_AI.AWS_Gen_AI(gptPromt + "from below topics"+ out_variable)
    # print(questions)
# Example usage
# bucket_name = 'bedrock-hiringagent'
read_all_files_from_s3("extracted-emails")
# read_all_files_from_s3(bucket_name)
