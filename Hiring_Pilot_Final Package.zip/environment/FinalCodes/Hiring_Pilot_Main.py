import os
import docx2txt
import Resume_Analysis
import GenMCQuestions
import Candidate_KnowledgeTest
import MultiFunctions as mf


#To read the resumes
def extract_information_from_resume(docx_path):
    resumeContent = docx2txt.process(docx_path)
    resume_info = resumeContent
    return resume_info
    
    
# reference to the folder path containing .docx files
folder_path = os.getcwd() + '/Inputs'


# loop through all the files in a folder
for file_name in os.listdir(folder_path):
    if file_name.endswith('.docx'):
        if file_name.startswith('Naukri*'):
            file_path = os.path.join(folder_path, file_name)
            resume_info = extract_information_from_resume(file_path)
            
            candidate_name, candidate_email, candidate_skills, result = Resume_Analysis.Analyse_resume(resume_info)
            print(result)
            
            if result == "Successful":
                no_Question = 2
                listmcq_Questions, job_title, job_Skills = GenMCQuestions.GenQuestions(candidate_name, candidate_email, no_Question)
                
                # Email_Subject = f"Profile shortlisted for {job_title}",
                # Email_Body = f"Hi {candidate_name}, \n You profile has been shortlisted for {job_title}. \n Please complete your assessment by clicking on the below given link. \n link: https://dd08f4ec4ced48a7b9cca762a57cf1d7.vfs.cloud9.us-west-2.amazonaws.com/ \n\n Regards,\nCode Warriors\nHiring Pilot"
                # jsondata = {
                # "EmailTo":"Srinidhi.Nadig@dentsu.com>",
                # "EmailSubject": Email_Subject,
                # "EmailBody":Email_Body
                # }
                        
                # sendEmailFunction(email_to,candidate_Name,selection_status)
                # EmailSendStatus = mf.send_Notification(json_Data=jsondata)
                # print(EmailSendStatus)

                for i in range(1,5):
                    try:
                        print(f"Attempt {i}: Execution started successfully...")
                        # Candidate_KnowledgeTest.start_Test(mcq_Questions=listmcq_Questions,jobTitle=job_title,jobSkills=job_Skills,candidateName=candidate_name, candidateEmail=candidate_email,candidateSkills=candidate_skills,candidateProfilescore="Successful")
                        Candidate_KnowledgeTest.start_Test(listmcq_Questions, job_title, job_Skills, candidate_name, candidate_email, candidate_skills, result)
                        break
                    except Exception as e:
                        if i < 5:
                            print(f"Attempt {i} failed: {e}. Retrying...")
                            continue
                        else:
                            print(f"Attempt {i} failed: {e}. Maximum attempts reached.")
                            break
            else:
                jsondata = {
                "EmailTo":candidate_email,
                "EmailSubject":"Test - Automation Engineer",
                "EmailBody":"Hi, Uipath, Python, AI, Power Platform"
                }
                
                EmailSendStatus = mf.send_Notification(json_Data=jsondata)
                print(EmailSendStatus)
