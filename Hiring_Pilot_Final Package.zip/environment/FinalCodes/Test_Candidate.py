from flask import Flask, render_template, request, jsonify
import MultiFunctions as mf
import EmailResponse
import json

app = Flask(__name__)

# mcqQuestionTemplate = ""
# canidate_Name = ""
# canidate_Email = ""
# canidate_Mobile = ""
# canidate_Experience = ""
# canidate_CurrentCTC = 0
# canidate_ExpectedCTC = 0
# canidate_Score = 0
# correct_answers = 0
# total_questions = 0
# canidate_Testscore = 0

mcqQuestions = """Q1: What is the purpose of the Get Text activity in UiPath?
    a) To extract text from an image or PDF document
    b) To display a message box with the text input from the user
    c) To retrieve the value of a variable or property
    Ans: a) To extract text from an image or PDF document

Q2: Which activity is used to pause the execution of a robot temporarily in UiPath?
    a) Delay
    b) Message Box
    c) Get Text
    Ans: a) Delay"""


def extract_mcq_questions(list_of_questions):
    lines = list_of_questions.strip().split('\n')
    questions = []
    current_question = None
    for line in lines:
        line = line.strip()
        if line.startswith(("Q", "a)", "b)", "c)", "d)", "e)", "Ans:")):
            if line.startswith("Q"):
                if current_question:
                    questions.append(current_question)
                current_question = {"Question": '', "options": [], "correct_answer": '',
                                    "selected_answer": "Yet To Select"}
                current_question["Question"] = line.replace('Question:', '').strip()
            elif line.startswith("a)", "b)", "c)", "d)"):
                current_question["options"].append(line)
            elif line.startswith("Ans:"):
                current_question["correct_answer"] = line.replace('Ans:', '').strip()

    if current_question:
        questions.append(current_question)

    return questions



@app.route('/')
def index():
    
    # print("Before parse - " + "\n")
    # print(mcq_QuestionTemplate)
    
    # questions_list = extract_mcq_questions(mcq_QuestionTemplate)
    
    # print("After parse template questions - " + "\n")
    # print(questions_list)
    
    return render_template('index.html', Canidatename= canidate_Name, Canidateemail=canidate_Email)


@app.route('/submitUserDetails', methods=['POST'])
def submit():
    global canidate_Mobile
    global canidate_Experience
    global canidate_CurrentCTC
    global canidate_ExpectedCTC

    # username = request.form['name']
    # useremail = request.form['email']
    canidate_Mobile = request.form['mobile']
    canidate_Experience = request.form['experience']
    canidate_CurrentCTC = request.form['CurrentCTC']
    canidate_ExpectedCTC = request.form['ExpectedCTC']
    
    if "year" not in canidate_Experience.lower():
        canidate_Experience = str(canidate_Experience) + " Year"
        print(canidate_Experience)
    
    if "L" not in canidate_CurrentCTC.lower():
        canidate_CurrentCTC = str(canidate_CurrentCTC) + " L"
        print(canidate_CurrentCTC)

    if "L" not in canidate_ExpectedCTC.lower():
        canidate_ExpectedCTC = str(canidate_ExpectedCTC) + " L"
        print(canidate_ExpectedCTC)
        
    
    questions_list = extract_mcq_questions(mcq_QuestionTemplate)
    
    return render_template('QuestionsTemplate.html', questions_list=questions_list, enumerate=enumerate)


@app.route('/submit', methods=['POST'])
def mcq_results():
    global canidate_Score
    global correct_answers
    global total_questions
    global canidate_Testscore
    global canidate_Testresult
    
    questions_list = extract_mcq_questions(mcq_QuestionTemplate)
    selectedAnswers = [value for key, value in request.form.items()]
    my_dict = {}
    for i, answer in enumerate(selectedAnswers, 1):
        question_key = f'Q{i}'
        my_dict[question_key] = answer
        questions_list[i - 1]['selected_answer'] = answer

    # Calculate the score
    canidate_Score = 0
    for question in questions_list:
        # if question['selected_answer'] == question['correct_answer']:
        #     canidate_Score += 1
            
        if question['correct_answer'].startswith(question['selected_answer']):
            canidate_Score += 1

    # Calculate the score
    correct_answers = sum(question['selected_answer'] == question['correct_answer'] for question in questions_list)
    total_questions = len(questions_list)

    # Calculate the percentage score
    canidate_Testscore = (correct_answers / total_questions) * 100
    # print(canidate_Testscore)
    if canidate_Testscore > 70:
        canidate_Testresult = "Successful"
    else:
        canidate_Testresult = "Unsuccessful"
    
    # Now, 'score' contains the total score
    print(f"Candidate MCQ test score: {canidate_Score} and test result: {canidate_Testresult}")
    
    jsondata = {
    "job_Title":job_Title,
    "job_Skills":job_Skills,
    "User_Name":canidate_Name,
    "User_Email":canidate_Email,
    "User_Experience":canidate_Experience,
    "User_CurrentCTC":canidate_CurrentCTC,
    "User_ExpectedCTC":canidate_ExpectedCTC,
    "Candidate_Skills":Candidate_Skills,
    "CandidateProfile_Score":Candidate_Profilescore,
    "Percentage_Score":canidate_Testscore,
    "Test_Result":canidate_Testresult
    }
    
    
    # response = mf.send_FinalNotification(json_Data=jsondata)
    # print(response)
    
    EmailResponse.sendFinalEmail(jsondata)
    return render_template('mcq_Results.html',mcq_questions=questions_list ,Username=canidate_Name,Useremail=canidate_Email,Usermobile=canidate_Mobile,Userexperience=canidate_Experience,TotalNoOfQuestions=total_questions,CorrectAnswers=correct_answers,ScoreinPercent=canidate_Testscore)


def shutdown_server():     
    func = request.environ.get('werkzeug.server.shutdown')     
    if func is None:         
        raise RuntimeError('Not running with the Werkzeug Server')     
    func()


@app.route('/close_page', methods=['POST'])
def close_page():
    print("Closing the server...")
    # os.kill(os.getpid(), 9)     
    shutdown_server()
    return
    # return jsonify(message='Page closed successfully')


# def start_Test(mcq_Questions, jobTitle, jobSkills, candidateName, candidateEmail, candidateSkills, candidateProfilescore):
global mcq_QuestionTemplate
global canidate_Name
global canidate_Email
global job_Title
global job_Skills
global Candidate_Skills
global Candidate_Profilescore

mcq_QuestionTemplate = mcqQuestions
canidate_Name = canidate_Name
canidate_Email = canidate_Email
job_Title = "Automation Engineer"
job_Skills = "Uipath, AI & ML, Power Platform"
Candidate_Skills = "Uipath, AI & ML, Power Platform"
Candidate_Profilescore = "Successful"
app.run(debug=True, host='0.0.0.0', port=8080)